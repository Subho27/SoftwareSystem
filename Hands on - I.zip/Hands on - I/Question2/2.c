#include<stdio.h>
int main(){
	while(1){
	}
	return 0;
}

//To run in background put & at the end of command
//It will run the process in background and also print process id
//now give command cd /proc/pid
//Different folders and files will contain process information
//such as cmdline, environ, status, exe, maps, fd, net etc.
